package com.example.secureexamapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ExamActivity : AppCompatActivity() {

    private lateinit var tvQuestion: TextView
    private lateinit var rgOptions: RadioGroup
    private lateinit var rbOption1: RadioButton
    private lateinit var rbOption2: RadioButton
    private lateinit var rbOption3: RadioButton
    private lateinit var rbOption4: RadioButton
    private lateinit var btnNext: Button

    private var questions: List<Question> = listOf()
    private var currentIndex = 0
    private var score = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exam)

        tvQuestion = findViewById(R.id.tvQuestion)
        rgOptions = findViewById(R.id.rgOptions)
        rbOption1 = findViewById(R.id.rbOption1)
        rbOption2 = findViewById(R.id.rbOption2)
        rbOption3 = findViewById(R.id.rbOption3)
        rbOption4 = findViewById(R.id.rbOption4)
        btnNext = findViewById(R.id.btnNext)

        questions = QuestionBank.getQuestions()

        showQuestion()

        btnNext.setOnClickListener {
            val selected = rgOptions.checkedRadioButtonId
            if (selected == -1) {
                Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val answer = when (selected) {
                R.id.rbOption1 -> 1
                R.id.rbOption2 -> 2
                R.id.rbOption3 -> 3
                R.id.rbOption4 -> 4
                else -> -1
            }

            if (answer == questions[currentIndex].correctAnswer) {
                score++
            }

            currentIndex++
            if (currentIndex < questions.size) {
                showQuestion()
            } else {
                showResult()
            }
        }
    }

    private fun showQuestion() {
        val q = questions[currentIndex]
        tvQuestion.text = q.questionText
        rbOption1.text = q.option1
        rbOption2.text = q.option2
        rbOption3.text = q.option3
        rbOption4.text = q.option4
        rgOptions.clearCheck()
        btnNext.text = if (currentIndex == questions.size - 1) "Finish" else "Next"
    }

    private fun showResult() {
        val result = "You scored $score out of ${questions.size}"
        Toast.makeText(this, result, Toast.LENGTH_LONG).show()
        finish()
    }
}
