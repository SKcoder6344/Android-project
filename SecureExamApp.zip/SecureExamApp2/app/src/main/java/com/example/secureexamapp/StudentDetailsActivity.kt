package com.example.secureexamapp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StudentDetailsActivity : AppCompatActivity() {

    private lateinit var nameText: TextView
    private lateinit var idText: TextView
    private lateinit var courseText: TextView
    private lateinit var backButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_details)

        nameText = findViewById(R.id.student_name_text)
        idText = findViewById(R.id.student_id_text)
        courseText = findViewById(R.id.student_course_text)
        backButton = findViewById(R.id.back_button)

        // In a real app, this would load student details from a database
        // For this example, we'll use hardcoded values
        nameText.text = "John Smith"
        idText.text = "ID: 12345"
        courseText.text = "Course: Computer Science"

        backButton.setOnClickListener {
            finish()
        }
    }
}
