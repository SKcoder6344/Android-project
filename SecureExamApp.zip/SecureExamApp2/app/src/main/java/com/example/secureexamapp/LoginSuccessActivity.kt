package com.example.secureexamapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class LoginSuccessActivity : AppCompatActivity() {

    private lateinit var proceedButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_success)

        proceedButton = findViewById(R.id.proceed_button)

        proceedButton.setOnClickListener {
            navigateToExam() // Changed method name for clarity
        }
    }

    private fun navigateToExam() {
        val intent = Intent(this, ExamActivity::class.java) // Changed to ExamActivity
        startActivity(intent)
        finish()
    }
}
