package com.example.secureexamapp

object QuestionBank {
    fun getQuestions(): List<Question> = listOf(
        Question(1, "What is the capital of France?", "London", "Berlin", "Paris", "Madrid", 3),
        Question(2, "Which planet is known as the Red Planet?", "Earth", "Mars", "Jupiter", "Saturn", 2),
        // Add more questions as needed
    )
}
