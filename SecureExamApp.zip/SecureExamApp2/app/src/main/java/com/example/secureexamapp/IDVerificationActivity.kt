package com.example.secureexamapp

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class IDVerificationActivity : AppCompatActivity() {

    private lateinit var idPreview: ImageView
    private lateinit var captureIdButton: Button
    private lateinit var verifyIdButton: Button
    private var idBitmap: Bitmap? = null

    companion object {
        private const val REQUEST_IMAGE_CAPTURE = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_id_verification)

        idPreview = findViewById(R.id.id_preview)
        captureIdButton = findViewById(R.id.capture_id_button)
        verifyIdButton = findViewById(R.id.verify_id_button)

        captureIdButton.setOnClickListener {
            dispatchTakePictureIntent()
        }

        verifyIdButton.setOnClickListener {
            if (idBitmap != null) {
                // In a real app, you would analyze the ID image
                // For this example, we'll simulate verification success
                if (verifyIdCard()) {
                    navigateToFaceVerification()
                } else {
                    navigateToFailScreen("ID verification failed")
                }
            } else {
                Toast.makeText(this, "Please capture your ID first", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(packageManager)?.also {
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap
            idBitmap = imageBitmap
            idPreview.setImageBitmap(imageBitmap)
            verifyIdButton.isEnabled = true
        }
    }

    private fun verifyIdCard(): Boolean {
        // In a real app, this would use OCR or other methods to verify the ID
        // For this example, we'll randomly succeed 90% of the time
        return (0..9).random() < 9
    }

    private fun navigateToFaceVerification() {
        val intent = Intent(this, FaceVerificationActivity::class.java)
        startActivity(intent)
    }

    private fun navigateToFailScreen(reason: String) {
        val intent = Intent(this, FailActivity::class.java)
        intent.putExtra("FAILURE_REASON", reason)
        startActivity(intent)
    }
}
