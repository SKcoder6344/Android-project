package com.example.secureexamapp

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class FaceVerificationActivity : AppCompatActivity() {

    private lateinit var facePreview: PreviewView
    private lateinit var statusText: TextView
    private lateinit var verifyFaceButton: Button
    private lateinit var cameraExecutor: ExecutorService
    private var faceDetected = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_face_verification)

        facePreview = findViewById(R.id.face_preview)
        statusText = findViewById(R.id.status_text)
        verifyFaceButton = findViewById(R.id.verify_face_button)

        cameraExecutor = Executors.newSingleThreadExecutor()

        startCamera()

        // For this example, we'll simulate face detection after a delay
        Handler(Looper.getMainLooper()).postDelayed({
            faceDetected = true
            statusText.text = "Face detected! Click Verify to continue."
            verifyFaceButton.isEnabled = true
        }, 3000)

        verifyFaceButton.setOnClickListener {
            if (faceDetected) {
                // In a real app, you would verify the face against the ID
                // For this example, we'll simulate verification success
                if (verifyFace()) {
                    navigateToLoginSuccess()
                } else {
                    navigateToFailScreen("Face verification failed")
                }
            }
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder()
                .build()
                .also {
                    it.setSurfaceProvider(facePreview.surfaceProvider)
                }

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_FRONT_CAMERA,
                    preview
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }, ContextCompat.getMainExecutor(this))
    }

    private fun verifyFace(): Boolean {
        // In a real app, this would compare the face with an ID or database
        // For this example, we'll randomly succeed 90% of the time
        return (0..9).random() < 9
    }

    private fun navigateToLoginSuccess() {
        val intent = Intent(this, LoginSuccessActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun navigateToFailScreen(reason: String) {
        val intent = Intent(this, FailActivity::class.java)
        intent.putExtra("FAILURE_REASON", reason)
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
