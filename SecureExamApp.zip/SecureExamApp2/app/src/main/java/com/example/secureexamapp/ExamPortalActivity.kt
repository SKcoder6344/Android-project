package com.example.secureexamapp

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ExamPortalActivity : AppCompatActivity() {

    private lateinit var timerText: TextView
    private lateinit var startExamButton: Button
    private lateinit var studentDetailsButton: Button
    private lateinit var countDownTimer: CountDownTimer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exam_portal)

        timerText = findViewById(R.id.timer_text)
        startExamButton = findViewById(R.id.start_exam_button)
        studentDetailsButton = findViewById(R.id.student_details_button)

        startExamButton.setOnClickListener {
            startExam()
        }

        studentDetailsButton.setOnClickListener {
            viewStudentDetails()
        }

        // Set up a timer for the exam (60 minutes)
        countDownTimer = object : CountDownTimer(60 * 60 * 1000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                val minutes = millisUntilFinished / 1000 / 60
                val seconds = (millisUntilFinished / 1000) % 60
                timerText.text = "Time: ${minutes}:${seconds.toString().padStart(2, '0')}"
            }

            override fun onFinish() {
                timerText.text = "Time: 0:00"
                // Auto-submit the exam
                finishExam()
            }
        }
    }

    private fun startExam() {
        // Start the timer
        countDownTimer.start()

        // Navigate to the actual exam
        val intent = Intent(this, OnlineExamActivity::class.java)
        startActivity(intent)
    }

    private fun viewStudentDetails() {
        val intent = Intent(this, StudentDetailsActivity::class.java)
        startActivity(intent)
    }

    private fun finishExam() {
        // Record exam completion and navigate to statistics
        val intent = Intent(this, StatisticsActivity::class.java)
        startActivity(intent)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Make sure to cancel the timer to prevent memory leaks
        countDownTimer.cancel()
    }
}
