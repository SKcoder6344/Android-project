package com.example.secureexamapp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import android.os.Environment

class StatisticsActivity : AppCompatActivity() {

    private lateinit var scoreText: TextView
    private lateinit var warningsCountText: TextView
    private lateinit var warningsListText: TextView
    private lateinit var closeButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistics)

        scoreText = findViewById(R.id.score_text)
        warningsCountText = findViewById(R.id.warnings_count_text)
        warningsListText = findViewById(R.id.warnings_list_text)
        closeButton = findViewById(R.id.close_button)

        // Get score from intent if available
        val score = intent.getIntExtra("SCORE", 0)
        val total = intent.getIntExtra("TOTAL", 0)
        scoreText.text = "Score: $score out of $total"

        // Load warnings from CSV
        loadWarnings()

        closeButton.setOnClickListener {
            finish()
        }
    }

    private fun loadWarnings() {
        try {
            val downloadsDir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            val file = File(downloadsDir, "exam_warnings.csv")

            if (file.exists()) {
                val warnings = mutableListOf<String>()
                var warningCount = 0

                // Read the CSV file
                val reader = BufferedReader(FileReader(file))
                var line: String?

                // Skip header
                reader.readLine()

                // Read warnings
                while (reader.readLine().also { line = it } != null) {
                    line?.let {
                        warnings.add(it)
                        warningCount++
                    }
                }

                reader.close()

                // Update UI
                warningsCountText.text = "Total warnings: $warningCount"
                warningsListText.text = warnings.joinToString("\n")
            } else {
                warningsCountText.text = "Total warnings: 0"
                warningsListText.text = "No warnings recorded"
            }
        } catch (e: Exception) {
            e.printStackTrace()
            warningsCountText.text = "Error loading warnings"
        }
    }
}
