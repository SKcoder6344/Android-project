package com.example.secureexamapp

data class Question(
    val id: Int,
    val questionText: String,
    val option1: String,
    val option2: String,
    val option3: String,
    val option4: String,
    val correctAnswer: Int // 1, 2, 3, or 4
)
