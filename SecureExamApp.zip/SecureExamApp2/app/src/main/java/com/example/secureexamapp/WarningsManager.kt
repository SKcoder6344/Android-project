package com.example.secureexamapp

import android.content.Context
import android.os.Environment
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

class WarningsManager(private val context: Context) {

    private val warningsList = mutableListOf<Warning>()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    fun recordWarning(studentId: String, warningType: String) {
        val timestamp = System.currentTimeMillis()
        val warning = Warning(studentId, warningType, timestamp)
        warningsList.add(warning)

        // Export to CSV after each warning
        exportWarningsToCSV()
    }

    private fun exportWarningsToCSV() {
        try {
            val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            val file = File(downloadsDir, "exam_warnings.csv")

            // Create the file if it doesn't exist
            if (!file.exists()) {
                file.createNewFile()
                // Write header
                val writer = FileWriter(file)
                writer.append("StudentID,WarningType,Timestamp\n")
                writer.flush()
                writer.close()
            }

            // Append warnings to the file
            val writer = FileWriter(file, true)
            for (warning in warningsList) {
                writer.append("${warning.studentId},${warning.warningType},${dateFormat.format(Date(warning.timestamp))}\n")
            }

            writer.flush()
            writer.close()

            // Clear the list after export
            warningsList.clear()

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    data class Warning(
        val studentId: String,
        val warningType: String,
        val timestamp: Long
    )
}
