package com.example.secureexamapp

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class OnlineExamActivity : AppCompatActivity() {

    private lateinit var questionText: TextView
    private lateinit var optionsGroup: RadioGroup
    private lateinit var nextButton: Button
    private lateinit var warningsManager: WarningsManager

    private val questions = listOf(
        Question("What is the capital of France?", listOf("London", "Paris", "Berlin", "Madrid"), 1),
        Question("Which planet is known as the Red Planet?", listOf("Venus", "Jupiter", "Mars", "Saturn"), 2),
        Question("What is the chemical symbol for gold?", listOf("Go", "Gd", "Au", "Ag"), 2)
    )

    private var currentQuestionIndex = 0
    private val userAnswers = IntArray(questions.size) { -1 }

    // For monitoring
    private val random = Random()
    private val monitoringHandler = Handler(Looper.getMainLooper())
    private val studentId = "12345" // In a real app, this would come from login

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_online_exam)

        questionText = findViewById(R.id.question_text)
        optionsGroup = findViewById(R.id.options_group)
        nextButton = findViewById(R.id.next_button)

        warningsManager = WarningsManager(this)

        // Display first question
        displayQuestion(currentQuestionIndex)

        nextButton.setOnClickListener {
            // Save current answer
            val selectedId = optionsGroup.checkedRadioButtonId
            if (selectedId != -1) {
                userAnswers[currentQuestionIndex] = when (selectedId) {
                    R.id.option_a -> 0
                    R.id.option_b -> 1
                    R.id.option_c -> 2
                    R.id.option_d -> 3
                    else -> -1
                }
            }

            // Move to next question or finish
            currentQuestionIndex++
            if (currentQuestionIndex < questions.size) {
                displayQuestion(currentQuestionIndex)
            } else {
                finishExam()
            }
        }

        // Start periodic monitoring
        startMonitoring()
    }

    private fun displayQuestion(index: Int) {
        val question = questions[index]
        questionText.text = question.text

        // Reset radio buttons
        optionsGroup.clearCheck()

        // Set option texts
        findViewById<TextView>(R.id.option_a_text).text = question.options[0]
        findViewById<TextView>(R.id.option_b_text).text = question.options[1]
        findViewById<TextView>(R.id.option_c_text).text = question.options[2]
        findViewById<TextView>(R.id.option_d_text).text = question.options[3]

        // Update button text for last question
        if (index == questions.size - 1) {
            nextButton.text = "Finish"
        }
    }

    private fun startMonitoring() {
        monitoringHandler.postDelayed(object : Runnable {
            override fun run() {
                // Simulate random checks
                // In a real app, you would check for actual suspicious activity

                // 10% chance of recording a warning
                if (random.nextInt(10) == 0) {
                    val warningTypes = listOf(
                        "face_not_detected",
                        "multiple_faces",
                        "looking_away",
                        "suspicious_movement"
                    )
                    val warningType = warningTypes[random.nextInt(warningTypes.size)]
                    warningsManager.recordWarning(studentId, warningType)
                }

                // Schedule next check
                monitoringHandler.postDelayed(this, 10000) // Check every 10 seconds
            }
        }, 10000)
    }

    private fun finishExam() {
        // Calculate score
        var score = 0
        for (i in questions.indices) {
            if (userAnswers[i] == questions[i].correctAnswerIndex) {
                score++
            }
        }

        // Navigate to statistics with results
        val intent = Intent(this, StatisticsActivity::class.java)
        intent.putExtra("SCORE", score)
        intent.putExtra("TOTAL", questions.size)
        startActivity(intent)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Remove monitoring callbacks
        monitoringHandler.removeCallbacksAndMessages(null)
    }

    data class Question(
        val text: String,
        val options: List<String>,
        val correctAnswerIndex: Int
    )
}
