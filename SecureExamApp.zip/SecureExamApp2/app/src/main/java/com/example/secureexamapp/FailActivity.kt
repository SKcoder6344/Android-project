package com.example.secureexamapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class FailActivity : AppCompatActivity() {

    private lateinit var failMessage: TextView
    private lateinit var retryButton: Button
    private lateinit var backToLoginButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fail)

        failMessage = findViewById(R.id.fail_message)
        retryButton = findViewById(R.id.retry_button)
        backToLoginButton = findViewById(R.id.back_to_login_button)

        // Get failure reason from intent if available
        val failureReason = intent.getStringExtra("FAILURE_REASON")
        if (!failureReason.isNullOrEmpty()) {
            failMessage.text = failureReason
        }

        retryButton.setOnClickListener {
            retry()
        }

        backToLoginButton.setOnClickListener {
            backToLogin()
        }
    }

    private fun retry() {
        // Check which activity we came from and go back there
        // In a real app, you'd track this with intent extras
        finish()
    }

    private fun backToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        // Clear the back stack
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
